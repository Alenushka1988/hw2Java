// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        int number = 345;
        System.out.println("Число " + number + " -> ");
        int num1 = number / 100;
        int num2 = (number / 10) % 10;
        int num3 = number % 10;
        System.out.println(num1 + ", " + num2 + ", " + num3);
    }
}